import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        ArrayList<Integer> pilha = new ArrayList<>();

        pilha.add(1);
        pilha.add(2);
        pilha.add(3);

        System.out.println("Pilha de pratos: " + pilha);


        if (!pilha.isEmpty()) {
            int pratoRemovido = pilha.remove(pilha.size() - 1);
            System.out.println("Prato desempilhado: " + pratoRemovido);
        }

        System.out.println("Pilha de pratos : " + pilha);
    }
}