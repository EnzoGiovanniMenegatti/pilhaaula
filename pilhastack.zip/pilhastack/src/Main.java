import java.util.Stack;

public class Main {

    public static void main(String[] args) {
        Stack<Integer> pilha = new Stack<>();

        pilha.push(1); // Adiciona no topo da pilha
        pilha.push(1);
        pilha.push(1);

        System.out.println("Pilha de pratos: " + pilha);

        if (!pilha.isEmpty()) {
            Integer pratoRemovido = pilha.pop(); // Remove o prato do topo da pilha
            System.out.println("Prato removido: " + pratoRemovido);
        } else {
            System.out.println("A pilha de pratos está vazia.");
        }

        System.out.println("Pilha de pratos após desempilhar: " + pilha);
    }
}
