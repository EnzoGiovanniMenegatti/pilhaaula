package com.example.aulapilha20;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AulaPilha20ApplicationTests {

	@Test
	void contextLoads() {
	}

}
