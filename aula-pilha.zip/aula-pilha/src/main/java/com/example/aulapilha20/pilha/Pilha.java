package com.example.aulapilha20.pilha;

public class Pilha {
    int quantidadeItens;
    Object[] pratos;


    public Pilha(int quantidadeItens, Object[] pratos) {
        this.quantidadeItens = quantidadeItens;
        this.pratos = pratos;
    }

    public Pilha() {

    }


    public int getQuantidadeItens() {

        return quantidadeItens;
    }

    public void setQuantidadeItens(int quantidadeItens) {

        this.quantidadeItens = quantidadeItens;
    }

    public Object[] getPratos() {

        return pratos;
    }

    public void setPratos(Object[] pratos) {

        this.pratos = pratos;
    }

}