package com.example.aulapilha20;

import com.example.aulapilha20.pilha.Pilha;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.util.Random;
import java.util.Scanner;

@SpringBootApplication
public class AulaPilha {

	public static void main(String[] args) {
		SpringApplication.run(AulaPilha.class, args);

		int[] pilha = new int[10];
		Random random = new Random();

		for (int i = 0; i < 10; i++) {
			pilha[i] = random.nextInt(10);
			System.out.println("Pilha [" + i + "] = " + pilha[i]);
		}

		for (int i = 9; i < pilha.length; i--) {
			pilha[i] = 0;
			System.out.println("Pilha [" + i + "] = " + pilha[i]);
		}
	}
}